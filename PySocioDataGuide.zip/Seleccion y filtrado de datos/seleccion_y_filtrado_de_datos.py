# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 10:29:56 2024

@author: Melisa
"""

# Librerias 
import pandas as pd
import numpy as np
import xlsxwriter


# Importar base de datos

%cd "F:\direccion donde se guarda la base"
df = pd.read_excel("data_2009.xlsx", sheet_name= "concentrado")

# Conocer las columnas o series que contiene el archivo
df.columns

# Extracción de la data por municipio 

df1 = df[df['Municipio'].isin(["Ahome","Calkini","Candelaria loxicha",
            "Carmen","Celestun","Champoton","Escarcega","Huatabampo","Hunucma","Palizada",
            "Paraiso","Pluma hidalgo","Progreso","San agustin loxicha",
            "San carlos yautepec","San francisco ozolotepec",
            "San juan mixtepec",
            "San juan mixtepec -dto. 08 -", "San juan mixtepec -dto. 26 -",
            "San juan ozolotepec","San marcial ozolotepec","San mateo piñas","San mateo rio hondo",
            "San miguel del puerto","San miguel suchixtepec","San pedro el alto","San pedro huamelula",
            "San pedro mixtepec",
            "San pedro mixtepec -dto. 22 -", "San pedro mixtepec -dto. 26 -",
            "San pedro pochutla","San sebastian rio hondo","Santa maria huatulco",
            "Santa maria ozolotepec","Santa maria tonameca","Santiago xanica","Santo domingo ozolotepec",
            "Oaxaca", "Sinaloa", "Sonora", "Tabasco", "Yucatan", "Campeche"])]

# Confirmar que todos los municipios se hayan seleccionado adecuadamente

df1['Municipio'].unique().size #Este solo funciona como un apartado general, para dar el numero de municipios

objetivo = ["Ahome","Calkini","Candelaria loxicha",
            "Carmen","Celestun","Champoton","Escarcega","Huatabampo","Hunucma","Palizada",
            "Paraiso","Pluma hidalgo","Progreso","San agustin loxicha",
            "San carlos yautepec","San francisco ozolotepec",
            "San juan mixtepec",
            "San juan mixtepec -dto. 08 -", "San juan mixtepec -dto. 26 -",
            "San juan ozolotepec","San marcial ozolotepec","San mateo piñas","San mateo rio hondo",
            "San miguel del puerto","San miguel suchixtepec","San pedro el alto","San pedro huamelula",
            "San pedro mixtepec",
            "San pedro mixtepec -dto. 22 -", "San pedro mixtepec -dto. 26 -",
            "San pedro pochutla","San sebastian rio hondo","Santa maria huatulco",
            "Santa maria ozolotepec","Santa maria tonameca","Santiago xanica","Santo domingo ozolotepec",
            "Oaxaca", "Sinaloa", "Sonora", "Tabasco", "Yucatan", "Campeche"]


realidad = d['Municipio'].unique()

realidad = d['Municipio'].unique()

faltantes = set(objetivo) - set(realidad)
print(faltantes)

# Confirmar si los datos faltantes efectivamente estos datos no se tienen o hubo un error en el código 

valores_a_buscar = faltantes  

resultados = df1[df1['Municipio'].isin(valores_a_buscar)]


if not resultados.empty:
    print("Los valores existen en la columna:")
    print(resultados)
else:
    print("Los valores no existen en la columna.")



# Confirmar que los municipios efectivamente pertenezcan a la entidad federativa adecuada

df1.columns

municipios_a_filtrar = realidad
entidades_a_filtrar = ["Oaxaca", "Sinaloa", "Sonora", "Tabasco", "Yucatan", "Campeche"]  

for municipio, entidad in zip(municipios_a_filtrar, entidades_a_filtrar):
    df2 = df1.drop(df1[(df1['Municipio'] == municipio) & (df1['Entidad'] != entidad)].index)
print(df2)


# Añadir el nombre al observatorio que pertenecen

df2.columns

conditionlist = [
    (df2['Entidad'] == 'Campeche'),
    ((df2['Entidad'] == 'Sonora') | (df2['Entidad'] == 'Sinaloa')),
    (df2['Municipio'] == 'Progreso'),
    (df2['Municipio'] == 'Calkini'),
    (df2['Municipio'] == 'Celestun'),
    (df2['Entidad'] == 'Oaxaca'),
    (df2['Entidad'] == 'Tabasco'),
    (df2['Municipio'] == 'Hunucma')
                ]

choicelist = ['Laguna de Terminos', 'Agiabampo',
              'Arrecife Alacranes', 'Celestun',
              'Celestun',
              'Copalita', 'Dos Bocas', 'Sisal'
              ]

df2['id_observatorio'] = np.select(conditionlist, choicelist)

# Añadir el año al que pertenece la data

df2['AÑO'] = '2009'

# Cambiar el nombre de las variables 
df2.columns

df3 = df2.rename(columns={'Entidad' : 'id_estado',
                          'Municipio' : 'id_municipio',
                          'AÑO' : 'año',
'A111A Producción bruta total (miles de pesos)' :	'Produccion Bruta Total',
'Actividad Económica' : 'Actividad Economica',
'UE Unidades económicas' :	'Numero de Unidades Economicas',
                          })

df3.columns

# Ordenar las variables 

df3=df3[['id_observatorio', 'id_estado', 'id_municipio', 
        'año', 'Actividad Economica',
       'Numero de Unidades Economicas', 'Produccion Bruta Total']]


# Convertir el observatorio en INDEX

df4=df3.set_index('id_observatorio')


# Guardar en formato .xlsx

%cd "F:\direccion a guardar"

df4.to_excel('2009_expt_campeche.xlsx', sheet_name = '2009')

