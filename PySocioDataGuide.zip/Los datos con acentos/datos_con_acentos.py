# -*- coding: utf-8 -*-
"""
Created on Thu Mar 21 10:57:35 2024

@author: Melisa
"""

# Librerias 
import pandas as pd
import xlsxwriter

# Función para eliminar tildes
def sin_tilde(MiCadena):
    replacements = (
    ("á", "a"),
    ("é", "e"),
    ("í", "i"),
    ("ó", "o"),
    ("ú", "u"),
    )
    for a, b in replacements:
        MiCadena = MiCadena.replace(a, b).replace(a.upper(), b.upper())
    return MiCadena

# Directorio donde se encuentra la informacion   

%cd "F:\direccion de donde se guardo la base a utilizr"


# Lee el archivo Excel
df = pd.read_excel("Índice_de_Desarrollo_Humano_Municipal_2010.xlsx", sheet_name="Datos")

# Directorio donde se gurdara la salida

workbook = xlsxwriter.Workbook("F:\direccion de donde se quiere guardar los datos de salida\nombre de la base de salida.xlsx")
worksheet = workbook.add_worksheet("nombre de la hoja de salida")

##ejemplo
#workbook = xlsxwriter.Workbook("F:\Beca Conacyt\Bases de datos_crudas\desarrollo humano\desarrollo_humano_2010_modificado.xlsx")
#worksheet = workbook.add_worksheet("concentrado")


# Contador para realizar la función para cada fila y columna
count = 0

# Para mantener el nombre de las columnas de datos de salida
for i, column_name in enumerate(df.columns):
    worksheet.write(count, i, sin_tilde(column_name))

# Aplicación de la función en los datos 
for index, row in df.iterrows():
    for i in range(0, df.shape[1]):
        worksheet.write(count + 1, i, sin_tilde(str(row[i])))
    count += 1

workbook.close()


##Lectura del nuevo archivo sin acentos
df = pd.read_excel("desarrollo_humano_2010_modificado.xlsx", sheet_name="concentrado")
